'use client';

import { Resume } from '@/lib/types/resume';
import { ExperienceItem, EducationItem, SkillItem, ProjectItem } from '@/lib/types/resume';
import { MarkdownRenderer } from './MarkdownRenderer';

export function CreativeTemplate({ resume }: { resume: Resume }) {
  const { personalInfo, sections } = resume;

  const experience = sections.find((s) => s.id === 'experience')?.items as ExperienceItem[] | undefined;
  const education = sections.find((s) => s.id === 'education')?.items as EducationItem[] | undefined;
  const skills = sections.find((s) => s.id === 'skills')?.items as SkillItem[] | undefined;
  const projects = sections.find((s) => s.id === 'projects')?.items as ProjectItem[] | undefined;

  return (
    <div className="bg-white text-gray-800">
      {/* Colorful side accent */}
      <div className="flex">
        <div className="w-2 bg-gradient-to-b from-purple-500 via-pink-500 to-red-500"></div>
        <div className="flex-1">
          {/* Header */}
          <div className="px-8 py-12 bg-gray-50">
            <h1 className="text-5xl font-black text-gray-900 mb-2 tracking-tight">{personalInfo.fullName}</h1>
            {personalInfo.summary && (
              <p className="text-lg text-gray-700 mt-4 leading-relaxed max-w-2xl">{personalInfo.summary}</p>
            )}
            
            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm mt-6">
              {personalInfo.email && (
                <div>
                  <span className="font-semibold text-purple-600">Email</span>
                  <div className="text-gray-700">{personalInfo.email}</div>
                </div>
              )}
              {personalInfo.phone && (
                <div>
                  <span className="font-semibold text-purple-600">Phone</span>
                  <div className="text-gray-700">{personalInfo.phone}</div>
                </div>
              )}
              {personalInfo.location && (
                <div>
                  <span className="font-semibold text-purple-600">Location</span>
                  <div className="text-gray-700">{personalInfo.location}</div>
                </div>
              )}
              {personalInfo.website && (
                <div>
                  <span className="font-semibold text-purple-600">Website</span>
                  <div className="text-gray-700">{personalInfo.website}</div>
                </div>
              )}
            </div>
          </div>

          {/* Main content */}
          <div className="px-8 py-10 grid grid-cols-3 gap-10">
            {/* Left column */}
            <div className="col-span-2">
              {/* Experience */}
              {experience && experience.length > 0 && sections.find((s) => s.id === 'experience')?.visible && (
                <div className="mb-12">
                  <h2 className="text-2xl font-black text-gray-900 mb-6 pb-2 border-b-4 border-purple-500">
                    EXPERIENCE
                  </h2>
                  {experience.map((item) => (
                    <div key={item.id} className="mb-8">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-lg font-bold text-gray-900">{item.title}</h3>
                        {item.startDate && (
                          <span className="text-xs font-semibold text-purple-600 uppercase">
                            {item.startDate} {item.endDate ? `- ${item.endDate}` : '- Now'}
                          </span>
                        )}
                      </div>
                      <p className="text-sm font-semibold text-gray-700 mb-3">{item.company}</p>
                      <MarkdownRenderer content={item.description} className="text-sm text-gray-700 leading-relaxed" />
                    </div>
                  ))}
                </div>
              )}

              {/* Projects */}
              {projects && projects.length > 0 && sections.find((s) => s.id === 'projects')?.visible && (
                <div className="mb-12">
                  <h2 className="text-2xl font-black text-gray-900 mb-6 pb-2 border-b-4 border-pink-500">
                    PROJECTS
                  </h2>
                  {projects.map((item) => (
                    <div key={item.id} className="mb-8 bg-gray-50 p-4 rounded-lg">
                      <h3 className="text-lg font-bold text-gray-900 mb-1">{item.name}</h3>
                      <p className="text-xs font-semibold text-purple-600 uppercase mb-3">{item.technologies}</p>
                      <MarkdownRenderer content={item.description} className="text-sm text-gray-700 leading-relaxed" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Right sidebar */}
            <div>
              {/* Skills */}
              {skills && skills.length > 0 && sections.find((s) => s.id === 'skills')?.visible && (
                <div className="mb-10">
                  <h3 className="text-lg font-black text-gray-900 mb-4 pb-2 border-b-4 border-red-500">SKILLS</h3>
                  <div className="space-y-2">
                    {skills.map((skill) => (
                      <div key={skill.id} className="flex items-center">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                        <span className="text-sm font-semibold text-gray-800">{skill.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Education */}
              {education && education.length > 0 && sections.find((s) => s.id === 'education')?.visible && (
                <div>
                  <h3 className="text-lg font-black text-gray-900 mb-4 pb-2 border-b-4 border-pink-500">EDUCATION</h3>
                  {education.map((item) => (
                    <div key={item.id} className="mb-6">
                      <h4 className="text-sm font-bold text-gray-900">{item.degree}</h4>
                      <p className="text-xs text-gray-700 mt-1">{item.school}</p>
                      {item.field && <p className="text-xs text-purple-600 font-semibold mt-1">{item.field}</p>}
                      {item.graduationYear && <p className="text-xs text-gray-600 mt-2">{item.graduationYear}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
