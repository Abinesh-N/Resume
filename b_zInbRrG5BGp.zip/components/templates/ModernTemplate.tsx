'use client';

import { Resume } from '@/lib/types/resume';
import { ExperienceItem, EducationItem, SkillItem, ProjectItem } from '@/lib/types/resume';
import { MarkdownRenderer } from './MarkdownRenderer';

interface ModernTemplateProps {
  resume: Resume;
}

export function ModernTemplate({ resume }: ModernTemplateProps) {
  const { personalInfo, sections, theme } = resume;

  return (
    <div className="w-full bg-white text-black p-10 font-sans">
      {/* Header - Side by side layout */}
      <div className="mb-8">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1
              className="text-5xl font-bold mb-1"
              style={{ color: theme.accentColor }}
            >
              {personalInfo.fullName}
            </h1>
            {personalInfo.summary && (
              <p className="text-gray-700 text-sm leading-relaxed max-w-md">
                {personalInfo.summary}
              </p>
            )}
          </div>
          <div className="text-right text-sm text-gray-600 space-y-1">
            {personalInfo.email && <p>{personalInfo.email}</p>}
            {personalInfo.phone && <p>{personalInfo.phone}</p>}
            {personalInfo.location && <p>{personalInfo.location}</p>}
          </div>
        </div>

        {/* Links */}
        <div className="flex gap-4 text-sm">
          {personalInfo.website && (
            <a href={personalInfo.website} style={{ color: theme.accentColor }}>
              Website
            </a>
          )}
          {personalInfo.linkedin && (
            <a
              href={`https://${personalInfo.linkedin}`}
              style={{ color: theme.accentColor }}
            >
              LinkedIn
            </a>
          )}
          {personalInfo.github && (
            <a href={`https://${personalInfo.github}`} style={{ color: theme.accentColor }}>
              GitHub
            </a>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-8">
        {/* Main content */}
        <div className="col-span-2 space-y-6">
          {sections.map((section) => {
            if (!section.visible || section.items.length === 0) return null;

            return (
              <div key={section.id}>
                <h2
                  className="text-xl font-bold mb-3 uppercase tracking-widest"
                  style={{ color: theme.accentColor }}
                >
                  {section.title}
                </h2>

                <div className="space-y-4">
                  {section.type === 'experience' &&
                    (section.items as ExperienceItem[]).map((item) => (
                      <div key={item.id} className="border-l-4 pl-4" style={{ borderColor: theme.accentColor }}>
                        <div className="flex justify-between items-baseline mb-1">
                          <h3 className="font-bold text-lg">{item.position}</h3>
                          <span className="text-xs text-gray-500 uppercase">
                            {item.startDate} - {item.currentlyWorking ? 'Present' : item.endDate}
                          </span>
                        </div>
                        <p className="text-sm font-semibold text-gray-600 mb-2">{item.company}</p>
                        <MarkdownRenderer content={item.description} className="text-sm text-gray-700" />
                      </div>
                    ))}

                  {section.type === 'education' &&
                    (section.items as EducationItem[]).map((item) => (
                      <div key={item.id} className="border-l-4 pl-4" style={{ borderColor: theme.accentColor }}>
                        <div className="flex justify-between items-baseline mb-1">
                          <h3 className="font-bold text-lg">{item.degree}</h3>
                          <span className="text-xs text-gray-500">{item.graduationDate}</span>
                        </div>
                        <p className="text-sm font-semibold text-gray-600">{item.school}</p>
                        <p className="text-sm text-gray-700">{item.field}</p>
                        {item.gpa && <p className="text-sm text-gray-500 mt-1">GPA: {item.gpa}</p>}
                      </div>
                    ))}

                  {section.type === 'projects' &&
                    (section.items as ProjectItem[]).map((item) => (
                      <div key={item.id} className="border-l-4 pl-4" style={{ borderColor: theme.accentColor }}>
                        <h3 className="font-bold text-lg mb-1">{item.name}</h3>
                        <p className="text-sm text-gray-600 mb-2">{item.technologies}</p>
                        <MarkdownRenderer content={item.description} className="text-sm text-gray-700" />
                        {item.link && (
                          <a href={item.link} className="text-sm mt-2 block" style={{ color: theme.accentColor }}>
                            View Project →
                          </a>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {sections.map((section) => {
            if (section.type !== 'skills' || !section.visible || section.items.length === 0) return null;

            return (
              <div key={section.id}>
                <h2
                  className="text-lg font-bold mb-3 uppercase tracking-wider"
                  style={{ color: theme.accentColor }}
                >
                  {section.title}
                </h2>
                <div className="space-y-2">
                  {(section.items as SkillItem[]).map((item) => (
                    <div
                      key={item.id}
                      className="px-3 py-2 rounded text-sm"
                      style={{
                        backgroundColor: `${theme.accentColor}15`,
                        color: theme.primaryColor,
                      }}
                    >
                      {item.name}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
