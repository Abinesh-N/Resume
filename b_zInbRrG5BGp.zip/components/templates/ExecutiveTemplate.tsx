'use client';

import { Resume } from '@/lib/types/resume';
import { ExperienceItem, EducationItem, SkillItem, ProjectItem } from '@/lib/types/resume';
import { MarkdownRenderer } from './MarkdownRenderer';

export function ExecutiveTemplate({ resume }: { resume: Resume }) {
  const { personalInfo, sections } = resume;

  const experience = sections.find((s) => s.id === 'experience')?.items as ExperienceItem[] | undefined;
  const education = sections.find((s) => s.id === 'education')?.items as EducationItem[] | undefined;
  const skills = sections.find((s) => s.id === 'skills')?.items as SkillItem[] | undefined;
  const projects = sections.find((s) => s.id === 'projects')?.items as ProjectItem[] | undefined;

  return (
    <div className="bg-white text-gray-800">
      {/* Header with accent background */}
      <div className="bg-gradient-to-r from-slate-700 to-slate-900 text-white px-8 py-12">
        <h1 className="text-4xl font-bold mb-2">{personalInfo.fullName}</h1>
        <p className="text-slate-200 text-lg mb-4">{personalInfo.summary}</p>
        
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
          {personalInfo.email && (
            <div>
              <span className="font-semibold">Email:</span> {personalInfo.email}
            </div>
          )}
          {personalInfo.phone && (
            <div>
              <span className="font-semibold">Phone:</span> {personalInfo.phone}
            </div>
          )}
          {personalInfo.location && (
            <div>
              <span className="font-semibold">Location:</span> {personalInfo.location}
            </div>
          )}
          {personalInfo.website && (
            <div>
              <span className="font-semibold">Website:</span> {personalInfo.website}
            </div>
          )}
          {personalInfo.linkedin && (
            <div>
              <span className="font-semibold">LinkedIn:</span> {personalInfo.linkedin}
            </div>
          )}
          {personalInfo.github && (
            <div>
              <span className="font-semibold">GitHub:</span> {personalInfo.github}
            </div>
          )}
        </div>
      </div>

      {/* Main content */}
      <div className="px-8 py-10">
        {/* Experience */}
        {experience && experience.length > 0 && sections.find((s) => s.id === 'experience')?.visible && (
          <div className="mb-10">
            <h2 className="text-2xl font-bold text-slate-800 border-b-2 border-slate-700 pb-3 mb-6">
              Professional Experience
            </h2>
            {experience.map((item, index) => (
              <div key={item.id} className={index > 0 ? 'mt-8' : ''}>
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg text-gray-900">{item.title}</h3>
                  {item.startDate && (
                    <span className="text-sm text-gray-600">
                      {item.startDate} {item.endDate ? `- ${item.endDate}` : '- Present'}
                    </span>
                  )}
                </div>
                <p className="text-slate-600 font-semibold mb-3">{item.company}</p>
                <MarkdownRenderer content={item.description} className="text-gray-700 leading-relaxed" />
              </div>
            ))}
          </div>
        )}

        {/* Education */}
        {education && education.length > 0 && sections.find((s) => s.id === 'education')?.visible && (
          <div className="mb-10">
            <h2 className="text-2xl font-bold text-slate-800 border-b-2 border-slate-700 pb-3 mb-6">
              Education
            </h2>
            {education.map((item, index) => (
              <div key={item.id} className={index > 0 ? 'mt-6' : ''}>
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-bold text-lg">{item.school}</h3>
                  {item.graduationYear && <span className="text-sm text-gray-600">{item.graduationYear}</span>}
                </div>
                <p className="text-slate-600 font-semibold">{item.degree} in {item.field}</p>
              </div>
            ))}
          </div>
        )}

        {/* Skills */}
        {skills && skills.length > 0 && sections.find((s) => s.id === 'skills')?.visible && (
          <div className="mb-10">
            <h2 className="text-2xl font-bold text-slate-800 border-b-2 border-slate-700 pb-3 mb-6">
              Core Competencies
            </h2>
            <div className="grid grid-cols-3 gap-3">
              {skills.map((skill) => (
                <div key={skill.id} className="bg-slate-100 px-4 py-3 rounded text-center font-semibold text-gray-700">
                  {skill.name}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projects && projects.length > 0 && sections.find((s) => s.id === 'projects')?.visible && (
          <div>
            <h2 className="text-2xl font-bold text-slate-800 border-b-2 border-slate-700 pb-3 mb-6">
              Notable Projects
            </h2>
            {projects.map((item, index) => (
              <div key={item.id} className={index > 0 ? 'mt-8' : ''}>
                <h3 className="font-bold text-lg text-gray-900 mb-1">{item.name}</h3>
                <p className="text-slate-600 font-semibold mb-3">{item.technologies}</p>
                <MarkdownRenderer content={item.description} className="text-gray-700 leading-relaxed" />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
