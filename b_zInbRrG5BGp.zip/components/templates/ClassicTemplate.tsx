'use client';

import { Resume } from '@/lib/types/resume';
import { ExperienceItem, EducationItem, SkillItem, ProjectItem } from '@/lib/types/resume';
import { MarkdownRenderer } from './MarkdownRenderer';

interface ClassicTemplateProps {
  resume: Resume;
}

export function ClassicTemplate({ resume }: ClassicTemplateProps) {
  const { personalInfo, sections, theme } = resume;

  return (
    <div
      className="w-full bg-white text-black p-12 font-serif leading-relaxed"
      style={{
        color: theme.primaryColor,
      }}
    >
      {/* Header */}
      <div className="mb-8 border-b-2 pb-6" style={{ borderColor: theme.accentColor }}>
        <h1 className="text-4xl font-bold mb-2">{personalInfo.fullName}</h1>
        <div className="flex gap-4 text-sm flex-wrap">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>•</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.location && <span>•</span>}
          {personalInfo.location && <span>{personalInfo.location}</span>}
        </div>
        <div className="flex gap-4 text-sm mt-2 flex-wrap">
          {personalInfo.website && (
            <>
              <a href={personalInfo.website} className="text-blue-600 hover:underline">
                {personalInfo.website}
              </a>
              <span>•</span>
            </>
          )}
          {personalInfo.linkedin && (
            <>
              <a
                href={`https://${personalInfo.linkedin}`}
                className="text-blue-600 hover:underline"
              >
                LinkedIn
              </a>
              <span>•</span>
            </>
          )}
          {personalInfo.github && (
            <a href={`https://${personalInfo.github}`} className="text-blue-600 hover:underline">
              GitHub
            </a>
          )}
        </div>
      </div>

      {/* Summary */}
      {personalInfo.summary && (
        <div className="mb-6">
          <p className="text-sm leading-relaxed">{personalInfo.summary}</p>
        </div>
      )}

      {/* Sections */}
      {sections.map((section) => {
        if (!section.visible || section.items.length === 0) return null;

        return (
          <div key={section.id} className="mb-6">
            <h2
              className="text-lg font-bold mb-3 uppercase tracking-wide"
              style={{ color: theme.accentColor }}
            >
              {section.title}
            </h2>

            <div className="space-y-4">
              {section.type === 'experience' &&
                (section.items as ExperienceItem[]).map((item) => (
                  <div key={item.id}>
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold">{item.position}</h3>
                      <span className="text-sm text-gray-600">
                        {item.startDate} {item.endDate && `- ${item.endDate}`}
                        {item.currentlyWorking && ' - Present'}
                      </span>
                    </div>
                    <p className="text-sm italic text-gray-600">{item.company}</p>
                    <MarkdownRenderer content={item.description} className="text-sm mt-1" />
                  </div>
                ))}

              {section.type === 'education' &&
                (section.items as EducationItem[]).map((item) => (
                  <div key={item.id}>
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold">{item.degree} in {item.field}</h3>
                      <span className="text-sm text-gray-600">{item.graduationDate}</span>
                    </div>
                    <p className="text-sm italic text-gray-600">{item.school}</p>
                    {item.gpa && <p className="text-sm text-gray-600">GPA: {item.gpa}</p>}
                  </div>
                ))}

              {section.type === 'skills' && (
                <div className="flex flex-wrap gap-2">
                  {(section.items as SkillItem[]).map((item) => (
                    <span
                      key={item.id}
                      className="px-3 py-1 bg-gray-100 text-sm rounded"
                      style={{ backgroundColor: `${theme.accentColor}15`, color: theme.primaryColor }}
                    >
                      {item.name}
                    </span>
                  ))}
                </div>
              )}

              {section.type === 'projects' &&
                (section.items as ProjectItem[]).map((item) => (
                  <div key={item.id}>
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold">{item.name}</h3>
                      {item.link && (
                        <a href={item.link} className="text-sm text-blue-600 hover:underline">
                          View
                        </a>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{item.technologies}</p>
                    <MarkdownRenderer content={item.description} className="text-sm mt-1" />
                  </div>
                ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
