export { ClassicTemplate } from './ClassicTemplate';
export { ModernTemplate } from './ModernTemplate';
export { MinimalTemplate } from './MinimalTemplate';
export { ExecutiveTemplate } from './ExecutiveTemplate';
export { CreativeTemplate } from './CreativeTemplate';

export const TEMPLATES = [
  {
    id: 'classic',
    name: 'Classic',
    description: 'Professional and traditional resume layout',
    component: ClassicTemplate,
  },
  {
    id: 'modern',
    name: 'Modern',
    description: 'Contemporary design with sidebar layout',
    component: ModernTemplate,
  },
  {
    id: 'minimal',
    name: 'Minimal',
    description: 'Clean and minimalist approach',
    component: MinimalTemplate,
  },
  {
    id: 'executive',
    name: 'Executive',
    description: 'Professional with accent header and bold typography',
    component: ExecutiveTemplate,
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'Vibrant design with color accents and sidebar',
    component: CreativeTemplate,
  },
];
