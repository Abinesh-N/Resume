'use client';

import { Resume } from '@/lib/types/resume';
import { ExperienceItem, EducationItem, SkillItem, ProjectItem } from '@/lib/types/resume';
import { MarkdownRenderer } from './MarkdownRenderer';

interface MinimalTemplateProps {
  resume: Resume;
}

export function MinimalTemplate({ resume }: MinimalTemplateProps) {
  const { personalInfo, sections, theme } = resume;

  return (
    <div className="w-full bg-white text-black p-8 font-sans text-sm">
      {/* Header */}
      <div className="mb-6 pb-4" style={{ borderBottomColor: theme.primaryColor, borderBottomWidth: '1px' }}>
        <h1 className="text-3xl font-light tracking-tight mb-2">{personalInfo.fullName}</h1>
        <div className="flex gap-3 text-xs text-gray-600 flex-wrap">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && personalInfo.email && <span>/</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.location && (personalInfo.email || personalInfo.phone) && <span>/</span>}
          {personalInfo.location && <span>{personalInfo.location}</span>}
        </div>
      </div>

      {/* Summary */}
      {personalInfo.summary && (
        <div className="mb-6 leading-relaxed text-gray-700">
          {personalInfo.summary}
        </div>
      )}

      {/* Two-column layout */}
      <div className="grid grid-cols-3 gap-8">
        {/* Main content - 2 columns */}
        <div className="col-span-2 space-y-6">
          {sections.map((section) => {
            if (!section.visible || section.items.length === 0 || section.type === 'skills') return null;

            return (
              <div key={section.id}>
                <h2
                  className="text-xs font-semibold uppercase tracking-widest mb-3"
                  style={{ color: theme.accentColor }}
                >
                  {section.title}
                </h2>

                <div className="space-y-4">
                  {section.type === 'experience' &&
                    (section.items as ExperienceItem[]).map((item) => (
                      <div key={item.id} className="text-xs">
                        <div className="flex justify-between mb-1">
                          <span className="font-semibold">{item.position}</span>
                          <span className="text-gray-500">
                            {item.startDate} – {item.currentlyWorking ? 'Present' : item.endDate}
                          </span>
                        </div>
                        <div className="text-gray-600 mb-1">{item.company}</div>
                        <MarkdownRenderer content={item.description} className="text-gray-700 leading-relaxed" />
                      </div>
                    ))}

                  {section.type === 'education' &&
                    (section.items as EducationItem[]).map((item) => (
                      <div key={item.id} className="text-xs">
                        <div className="flex justify-between mb-1">
                          <span className="font-semibold">{item.degree} in {item.field}</span>
                          <span className="text-gray-500">{item.graduationDate}</span>
                        </div>
                        <div className="text-gray-600">{item.school}</div>
                        {item.gpa && <div className="text-gray-500">GPA: {item.gpa}</div>}
                      </div>
                    ))}

                  {section.type === 'projects' &&
                    (section.items as ProjectItem[]).map((item) => (
                      <div key={item.id} className="text-xs">
                        <div className="font-semibold mb-1">{item.name}</div>
                        <div className="text-gray-600 mb-1">{item.technologies}</div>
                        <MarkdownRenderer content={item.description} className="text-gray-700 leading-relaxed" />
                        {item.link && (
                          <a href={item.link} className="text-blue-600 hover:underline mt-1 block">
                            {item.link}
                          </a>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Sidebar - Skills */}
        <div>
          {sections.map((section) => {
            if (section.type !== 'skills' || !section.visible || section.items.length === 0) return null;

            return (
              <div key={section.id}>
                <h2
                  className="text-xs font-semibold uppercase tracking-widest mb-3"
                  style={{ color: theme.accentColor }}
                >
                  {section.title}
                </h2>
                <div className="space-y-2">
                  {(section.items as SkillItem[]).map((item) => (
                    <div key={item.id} className="text-xs text-gray-700">
                      {item.name}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
