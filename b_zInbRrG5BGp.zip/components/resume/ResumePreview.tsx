'use client';

import { Resume } from '@/lib/types/resume';
import { TEMPLATES } from '@/components/templates';

interface ResumePreviewProps {
  resume: Resume;
}

export function ResumePreview({ resume }: ResumePreviewProps) {
  const renderTemplate = () => {
    const template = TEMPLATES.find((t) => t.id === resume.templateId);
    
    if (!template || !template.component) {
      const defaultTemplate = TEMPLATES[0];
      return defaultTemplate.component ? <defaultTemplate.component resume={resume} /> : null;
    }
    
    const TemplateComponent = template.component;
    return <TemplateComponent resume={resume} />;
  };

  return (
    <div className="w-full h-full bg-white rounded-lg overflow-y-auto">
      <div className="bg-white p-8 shadow-sm border-l border-t border-r border-b border-border">
        {renderTemplate()}
      </div>
    </div>
  );
}
