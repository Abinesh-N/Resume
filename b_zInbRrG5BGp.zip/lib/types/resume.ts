export type SectionType = 'experience' | 'education' | 'skills' | 'projects' | 'certifications';

export interface PersonalInfo {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  summary: string;
  website?: string;
  linkedin?: string;
  github?: string;
}

export interface ExperienceItem {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  currentlyWorking: boolean;
  description: string;
}

export interface EducationItem {
  id: string;
  school: string;
  degree: string;
  field: string;
  graduationDate: string;
  gpa?: string;
}

export interface SkillItem {
  id: string;
  name: string;
  category?: string;
}

export interface ProjectItem {
  id: string;
  name: string;
  description: string;
  technologies: string;
  link?: string;
}

export interface CertificationItem {
  id: string;
  name: string;
  issuer: string;
  issueDate: string;
  expirationDate?: string;
  credentialId?: string;
  credentialUrl?: string;
}

export interface Section {
  id: string;
  type: SectionType;
  title: string;
  visible: boolean;
  order: number;
  items: ExperienceItem[] | EducationItem[] | SkillItem[] | ProjectItem[] | CertificationItem[];
}

export interface Theme {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

export interface Resume {
  id: string;
  title: string;
  personalInfo: PersonalInfo;
  sections: Section[];
  templateId: string;
  theme: Theme;
  editingMode: 'simple' | 'advanced';
  createdAt: string;
  updatedAt: string;
}

export const DEFAULT_THEME: Theme = {
  primaryColor: '#1a1a1a',
  secondaryColor: '#444444',
  accentColor: '#0066cc',
};

export const DEFAULT_RESUME: Resume = {
  id: '',
  title: 'My Resume',
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    summary: '',
    website: '',
    linkedin: '',
    github: '',
  },
  sections: [
    {
      id: 'experience',
      type: 'experience',
      title: 'Professional Experience',
      visible: true,
      order: 0,
      items: [],
    },
    {
      id: 'education',
      type: 'education',
      title: 'Education',
      visible: true,
      order: 1,
      items: [],
    },
    {
      id: 'skills',
      type: 'skills',
      title: 'Skills',
      visible: true,
      order: 2,
      items: [],
    },
    {
      id: 'projects',
      type: 'projects',
      title: 'Projects',
      visible: true,
      order: 3,
      items: [],
    },
  ],
  templateId: 'classic',
  theme: DEFAULT_THEME,
  editingMode: 'simple',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};
