import html2pdf from 'html2pdf.js';
import { Resume } from '@/lib/types/resume';

export async function exportResumeToPDF(resume: Resume, filename: string = 'resume.pdf') {
  try {
    // Get the resume preview HTML element
    const element = document.getElementById('resume-preview-content');
    
    if (!element) {
      throw new Error('Resume preview element not found');
    }

    // Clone the element to avoid modifying the original
    const cloneElement = element.cloneNode(true) as HTMLElement;
    
    // Remove any interactive elements
    cloneElement.querySelectorAll('button, input, textarea').forEach((el) => {
      el.remove();
    });

    // PDF options
    const options = {
      margin: [10, 10, 10, 10], // margins in mm
      filename: filename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { orientation: 'portrait', unit: 'mm', format: 'a4' },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
    };

    // Generate PDF
    html2pdf().set(options).from(cloneElement).save();
    
    return true;
  } catch (error) {
    console.error('PDF export error:', error);
    throw error;
  }
}

export function generatePDFFilename(resumeTitle: string): string {
  const timestamp = new Date().toISOString().split('T')[0];
  const sanitized = resumeTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return `${sanitized}-${timestamp}.pdf`;
}
