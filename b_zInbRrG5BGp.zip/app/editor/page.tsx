'use client';

import { useResume } from '@/lib/hooks/useResume';
import { PersonalInfoForm } from '@/components/resume/PersonalInfoForm';
import { SectionEditor } from '@/components/resume/SectionEditor';
import { ResumePreview } from '@/components/resume/ResumePreview';
import { EditingModeToggle } from '@/components/resume/EditingModeToggle';
import { ThemeCustomizer } from '@/components/resume/ThemeCustomizer';
import { DownloadManager } from '@/components/resume/DownloadManager';
import { TEMPLATES } from '@/components/templates';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Download, RotateCcw } from 'lucide-react';
import { ExperienceItem, EducationItem, SkillItem, ProjectItem } from '@/lib/types/resume';

export default function EditorPage() {
  const {
    resume,
    isLoading,
    updateResume,
    updatePersonalInfo,
    updateSection,
    addSectionItem,
    removeSectionItem,
    updateSectionItem,
    resetResume,
  } = useResume();

  if (isLoading || !resume) {
    return (
      <div className="h-full flex items-center justify-center">
        <p className="text-muted-foreground">Loading resume...</p>
      </div>
    );
  }

  const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const handleAddSectionItem = (sectionId: string) => {
    const section = resume.sections.find((s) => s.id === sectionId);
    if (!section) return;

    let newItem: any;

    switch (section.type) {
      case 'experience':
        newItem = {
          id: generateId(),
          company: '',
          position: '',
          startDate: '',
          endDate: '',
          currentlyWorking: false,
          description: '',
        } as ExperienceItem;
        break;
      case 'education':
        newItem = {
          id: generateId(),
          school: '',
          degree: '',
          field: '',
          graduationDate: '',
          gpa: '',
        } as EducationItem;
        break;
      case 'skills':
        newItem = {
          id: generateId(),
          name: '',
          category: '',
        } as SkillItem;
        break;
      case 'projects':
        newItem = {
          id: generateId(),
          name: '',
          description: '',
          technologies: '',
          link: '',
        } as ProjectItem;
        break;
    }

    addSectionItem(sectionId, newItem);
  };

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-20 px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Resume Builder</h1>
            <p className="text-sm text-muted-foreground mt-1">Create and customize your professional resume</p>
          </div>
          <div className="flex gap-3">
            <Select value={resume.templateId} onValueChange={(value) => updateResume({ templateId: value })}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TEMPLATES.map((template) => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={resetResume} title="Reset to blank resume">
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>

        {/* Download Section */}
        <div className="border-t pt-4">
          <div className="max-w-sm">
            <DownloadManager resume={resume} />
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div />
          <EditingModeToggle 
            value={resume.editingMode} 
            onChange={(mode) => updateResume({ editingMode: mode })} 
          />
        </div>
      </header>

      {/* Main Editor Area */}
      <div className="flex-1 grid grid-cols-2 gap-6 p-6 overflow-hidden">
        {/* Left: Editor Panel */}
        <div className="overflow-y-auto space-y-6 pr-2">
          {/* Personal Info Form */}
          <PersonalInfoForm data={resume.personalInfo} onChange={updatePersonalInfo} />

          {/* Theme Customizer */}
          <ThemeCustomizer 
            theme={resume.theme}
            onUpdateTheme={(updates) => updateResume({ theme: { ...resume.theme, ...updates } })}
          />

          {/* Section Editors */}
          {resume.sections.map((section) => (
            <SectionEditor
              key={section.id}
              section={section}
              onUpdateSection={(updates) => updateSection(section.id, updates)}
              onAddItem={() => handleAddSectionItem(section.id)}
              onRemoveItem={(itemId) => removeSectionItem(section.id, itemId)}
              onUpdateItem={(itemId, updates) => updateSectionItem(section.id, itemId, updates)}
              editingMode={resume.editingMode}
            />
          ))}
        </div>

        {/* Right: Preview Panel */}
        <div className="overflow-y-auto bg-muted rounded-lg p-6 shadow-sm border">
          <div id="resume-preview-content">
            <ResumePreview resume={resume} />
          </div>
        </div>
      </div>
    </div>
  );
}
